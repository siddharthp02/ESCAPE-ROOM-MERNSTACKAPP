

		room1 = document.getElementById("room1")
		room2 = document.getElementById("room2")
		toggleRoom = document.getElementById("b1")
		dial = document.getElementById("dial")
		mat = document.getElementById('mat')
		clock = document.getElementById('clock')
		teddy = document.getElementById("teddy")
		table = document.getElementById("table")
		grid = document.getElementById("grid")
