document.onload = function(){
	// var grid_array = [[0,0,0,0,0,0,0,0,0,0], [0,0,0,0,0,0,0,0,0,0], [0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0]];

	// room1 = document.getElementById("room1")
	// room2 = document.getElementById("room2")
	// dial = document.getElementById("dial")
	// mat = document.getElementById('mat')
	// clock = document.getElementById('clock')

	console.log("loaded")
	
	// ReactDOM.render(<MiniDrawer/>, document.getElementById("fullpage"))
	// import axios from 'axios'
	// function sendtime(hours,mins,seconds){
	// 	const payload = {
	// 	hours: hours,
	// 	mins:min,
	// 	secs:seconds
	// 	}

	// 	axios({
	// 	url:'/api/sendtime',
	// 	method: 'POST',
	// 	data: payload
	// 	})
	// 	.then(()=> {
	// 		alert("time sent")
	// 		console.log("Data has been sent to the server")
			
			
	// 	})
	// 	.catch(()=> {
	// 		alert("time not sent")
	// 	})
	// }
	// button = document.getElementById("wowow")
	// button.addEventListener("click",()=>{
	// 	console.log("hello i am clicked")
	// 	sendtime(2,3,4)
	// })


}