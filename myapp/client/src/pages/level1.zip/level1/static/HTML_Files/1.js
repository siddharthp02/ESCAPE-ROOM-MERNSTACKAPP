
// window.onload = function(){
// 	// var grid_array = [[0,0,0,0,0,0,0,0,0,0], [0,0,0,0,0,0,0,0,0,0], [0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0]];

// 	// room1 = document.getElementById("room1")
// 	// room2 = document.getElementById("room2")
// 	// dial = document.getElementById("dial")
// 	// mat = document.getElementById('mat')
// 	// clock = document.getElementById('clock')

// 	console.log("wowowd")
    
//         console.log("booyaka")
//         function setCookie(cname, cvalue, exdays) {
//         const d = new Date();
//         d.setTime(d.getTime() + (exdays*24*60*60*1000));
//         let expires = "expires="+ d.toUTCString();
//         document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
//     }
//     function getCookie(cname) {
//         let name = cname + "=";
//         let decodedCookie = decodeURIComponent(document.cookie);
//         let ca = decodedCookie.split(';');
//         for(let i = 0; i <ca.length; i++) {
//           let c = ca[i];
//           while (c.charAt(0) == ' ') {
//             c = c.substring(1);
//           }
//           if (c.indexOf(name) == 0) {
//             return c.substring(name.length, c.length);
//           }
//         }
//         return "";
//       }
//       function checkCookie() {
//         let username = getCookie("username");
//         if (username != "") {
//          alert("Welcome again " + username);
//         } else {
//           username = prompt("Please enter your name:", "");
//           if (username != "" && username != null) {
//             setCookie("username", username, 365);
//           }
//         }
//       }
      
//       checkCookie()
	
// 	// ReactDOM.render(<MiniDrawer/>, document.getElementById("fullpage"))
	
// 	// function sendtime(hours,mins,seconds){
// 	// 	const payload = {
// 	// 	hours: hours,
// 	// 	mins:mins,
// 	// 	secs:seconds
// 	// 	}
// 	// 	axios({
// 	// 	url:'http://127.0.0.1:8887/api/sendtime',
// 	// 	method: 'POST',
// 	// 	data: payload
        
// 	// 	})
// 	// 	.then(()=> {
// 	// 		alert("time sent")
// 	// 		console.log("Data has been sent to the server")
			
			
// 	// 	})
// 	// 	.catch(()=> {
// 	// 		alert("time not sent")
// 	// 	})
// 	// }
// 	// var stuff = document.getElementById("wowow")
//     // console.log(stuff.tagName)
// 	// stuff.onclick = function(){console.log("ive been clicked");sendtime(1,2,3)};
   

// }
